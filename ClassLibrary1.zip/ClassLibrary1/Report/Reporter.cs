﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;

namespace ClassLibrary1.Report
{
    internal class Reporter
    {
        public static ExtentReports SuiteReport { get; set; }

        static Reporter()
        {
            SuiteReport = new ExtentReports();
            SuiteReport.AttachReporter(new ExtentHtmlReporter(@"C:\Test\Demo\test.html"));
        }
    }
}
