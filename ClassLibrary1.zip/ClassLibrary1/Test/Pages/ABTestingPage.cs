﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Test.Pages
{
    internal class ABTestingPage
    {
        public static By MainHeader => By.XPath("//h3");
    }
}
