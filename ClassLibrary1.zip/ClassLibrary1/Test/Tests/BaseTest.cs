﻿using AventStack.ExtentReports;
using ClassLibrary1.Report;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NUnit.Framework;
using NUnit.Framework.Constraints;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Test.Tests
{
    [TestFixture]
    internal class BaseTest
    {
        protected IWebDriver Driver { get; set; }

        public static ExtentTest TestReport { get; set; }

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
        }

        [OneTimeTearDown]
        public void OneTimeTearDown()
        {

        }

        [SetUp]
        public void Setup()
        {
            AppSettings appSettings = JsonConvert.DeserializeObject<AppSettings>(File.ReadAllText("appsettings.json"));

            TestReport = Reporter.SuiteReport.CreateTest(TestContext.CurrentContext.Test.FullName);

            switch (appSettings.Browser)
            {
                case "Chrome" :
                    Driver = new ChromeDriver();
                    break;
                default:
                    Driver = new ChromeDriver();
                    break;
            }

            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Driver.Manage().Window.Maximize();
            Driver.Navigate().GoToUrl(appSettings.HomePage);
        }

        [TearDown]
        public void TearDown()
        {
            Driver.Quit();

            if (TestContext.CurrentContext.Result.Outcome.Status == NUnit.Framework.Interfaces.TestStatus.Failed)
            {
                TestReport.Fail(TestContext.CurrentContext.Result.Message);
            }
            else
            {
                TestReport.Pass(TestContext.CurrentContext.Result.Message);
            }
        }

    }
}
