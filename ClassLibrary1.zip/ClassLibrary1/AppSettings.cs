﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    internal class AppSettings
    {
        public string Browser { get; set; }

        public string HomePage { get; set; }
    }
}
