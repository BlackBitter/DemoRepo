﻿using System;

namespace ClassLibrary1
{
    public static class Student
    {


        static Student()
        {

        }
    }
}
